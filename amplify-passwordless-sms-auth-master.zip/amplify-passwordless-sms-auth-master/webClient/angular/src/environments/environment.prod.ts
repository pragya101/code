export const environment = {
  production: true,
  region: 'your region',
  userPoolId: 'your user pool id',
  userPoolWebClientId: 'your client id',
};